<?php if ( is_active_sidebar( 'primary-new' ) ) { ?>
    <ul id="primary-new">
        <?php dynamic_sidebar('primary-new'); ?>
    </ul>
<?php } ?>
<?php
    if ( function_exists( 'atbs_extension_single_entry_interaction' ) ) {
        echo atbs_extension_single_entry_interaction(get_the_ID());
    }
?>
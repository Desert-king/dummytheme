<div class="scroll-count-percent">
    <svg class="progress-scroll" width="120" height="120" viewBox="0 0 120 120">
        <circle class="progress__meter" cx="60" cy="60" r="54" stroke-width="3" />
        <circle class="progress__value" cx="60" cy="60" r="54" stroke-width="6" />
    </svg>
    <div class="percent-number"><span class="percent-number-text">0</span> %</div>
</div>
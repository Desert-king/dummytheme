<?php
    if ( ! class_exists( 'Redux' ) ) {
        return;
    }

    require_once( ATBS_THEMEOPTONS_SECTIONS.'general-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'spacing-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'typography-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'module-heading-styles.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'page-header-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'dedicated-header-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'social-media-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'single-page-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'advance-single-page.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'page-settings.php' );
    require_once( ATBS_THEMEOPTONS_SECTIONS.'footer.php' );